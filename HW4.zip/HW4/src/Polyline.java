import java.util.ArrayList;
import java.util.Arrays;
//import java.util.Iterator;

public class Polyline {
	
	private ArrayList<Point> Polyline = new ArrayList<Point>();
	
	public void add(Point p) {
		Polyline.add(p);
	}
	
	// Because we couldn't get toString() to work
	public void print() {
		System.out.print("[ ");
		for(int i=0; i < Polyline.size(); i++) {
			System.out.print(Polyline.get(i).toString() + " ");
		}
		System.out.print("]");
	}
	
	public String toString() {
		return this.type() + " " + Arrays.deepToString(getPoints().toArray());
	}

}
