import java.util.ArrayList;
import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		
		Point p1 = new Point(1,2);
		Point p2 = new Point(2,1);
		
		Polyline poly = new Polyline();
		//System.out.println(poly.toString() );
		poly.add(p1);
		poly.add(p2);
		poly.print();
		
		//System.out.println(poly.size() );
		
		fire f = new fire(1,10,10,0);
		System.out.println(f);


	}

}
