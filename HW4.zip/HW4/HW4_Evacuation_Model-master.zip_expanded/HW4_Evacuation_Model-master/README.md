# HW4_Evacuation_Model
A model of evacuation for Geography 178 at UCSB
