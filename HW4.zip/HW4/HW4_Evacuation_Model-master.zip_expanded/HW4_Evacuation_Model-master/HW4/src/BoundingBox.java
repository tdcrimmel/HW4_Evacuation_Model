public class BoundingBox {
	private Point LL;
	private Point UR;
	
	//slope determines the direction of the middle line, true is positive, false is negative
	private boolean slope;
	
	public BoundingBox(Point p1, Point p2) {
		if (p1.getX() > p2.getX() && p1.getY() > p2.getY()) {
			this.UR = p1;
			this.LL = p2;
			this.slope = true;
		}
		if (p1.getX() > p2.getX() && p1.getY() < p2.getY()) {
			this.UR = p1;
			this.LL = p2;
			this.slope = false;
		}
		if (p1.getX() < p2.getX() && p1.getY() < p2.getY()) {
			this.UR = p2;
			this.LL = p1;
			this.slope = true;
		}
		if (p1.getX() < p2.getX() && p1.getY() > p2.getY()) {
			this.UR = p2;
			this.LL = p1;
			this.slope = false;
		}	
	}
	
	public BoundingBox(double x1, double y1, double x2, double y2) {
		if (x1 > x2 && y1 > y2) {
			this.UR = new Point(x1,y1);
			this.LL = new Point(x2,y2);
			this.slope = true;
		}
		if (x1 > x2 && y1 < y2) {
			this.UR = new Point(x1,y1);
			this.LL = new Point(x2,y2);
			this.slope = false;
		}
		if (x1 < x2 && y1 < y2) {
			this.UR = new Point(x2,y2);
			this.LL = new Point(x1,y1);
			this.slope = true;
		}
		if (x1 < x2 && y1 > y2) {
			this.UR = new Point(x2,y2);
			this.LL = new Point(x1,y1);
			this.slope = false;
		}
	}
	
	public Point getLL() {
		return this.LL;
	}
	
	public void setLL(Point p1) {
		this.LL = p1;
	}
	
	public Point getUR() {
		return this.UR;
	}
	
	public void setUR(Point p2) {
		this.UR = p2;
	}
	
	public String getType() {
		return "Bounding Box";
	}
	
	public boolean is2D() {
		if (LL.getX() == UR.getX() || LL.getY() == UR.getY()) 
			return false;
		else {
			return true;
		}
	}
	
	public boolean isInside(Point p) {
		if (LL.getX() > p.getX() || UR.getX() < p.getX())
			return false;
		if (LL.getY() > p.getY() || UR.getY() > p.getY())
			return false;
		else
			return true;
	}
	
	public double calcArea() {
		double length = Math.abs(UR.getX() - LL.getX());
		double width = Math.abs(UR.getY() - LL.getY());	
		return (length * width);
	}
	
	
	
		
}