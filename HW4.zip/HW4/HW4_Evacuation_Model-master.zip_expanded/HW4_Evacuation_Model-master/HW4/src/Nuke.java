
public class Nuke extends Disaster{
	
	public Nuke(double x1, double y1, double x2, double y2) {
		super(x1, x2, y1, y2);
		this.setDuration(100000);
	}
	
	public Nuke(Point LL, Point UR) {
		super(LL, UR);
		this.setDuration(100000);
	}
	
	public String getType() {
		return "Nuke";
	}

}
