import java.util.ArrayList;

public class Polygon {
	
	private Polyline pline = new Polyline();
	
	public Polygon(Polyline pline) {
		
	}

}
