package HW4_pkg;
import java.util.ArrayList;
import java.util.Iterator;

public class Test {

	public static void main(String[] args) {

		// Create some Points
		Point p1 = new Point(8,2);
		Point p2 = new Point(0,9);
		Point p3 = new Point(0,3);
		Point p4 = new Point(8,2);
		Point p5 = new Point(5,0);
		Point p6 = new Point(4,1);
		Point p7 = new Point(2,3);
		Point p8 = new Point(0,3);
		Point p9 = new Point(6,7);
		Point p10 = new Point(9,0);
		Point p11 = new Point(8,2);
		Point p12 = new Point(0,0);
		Point p13 = new Point(10,10);
		Point p14 = new Point(5,5);
		
		// Test some Point methods
		System.out.println("The distance from " + p1.toString() + " to " + p2.toString() + " is " + p1.distance(p2) + "\n");
		
		// Create a Polyline
		ArrayList<Point> pArray = new ArrayList<Point>();
		pArray.add(p1);
		Polyline pLine = new Polyline(pArray);
		
		// Test some Polyline methods
		System.out.println(pLine.toString() + "\nSize: " + pLine.size() + "\nLength: " + pLine.getLength() + "\nValid: " + pLine.checkValid() + "\n");
		pLine.addPoint(p2);
		System.out.println(pLine.toString() + "\nSize: " + pLine.size() + "\nLength: " + pLine.getLength() + "\nValid: " + pLine.checkValid() + "\n");
		
		// Create a Polygon
		Polygon pGon = new Polygon(pArray);
		
		// Test some Polygon methods
		System.out.println(pGon.toString() + "\nValid: " + pGon.isValid() + "\n");
		pGon.makeValid();
		pGon.addPoint(p3);
		System.out.println(pGon.toString() + "\nValid: " + pGon.isValid() + "\n");
		pGon.makeValid();
		System.out.println(pGon.toString() + "\nValid: " + pGon.isValid());
		pGon.makeValid();
		System.out.println();
		
		// Create the Bounding Box
		BoundingBox bb = new BoundingBox(p4, p11);
		
		// Test the Bounding Box
		System.out.println(bb.toString());
		System.out.println("The bounding box two dimensional: " + bb.is2D() + "\n");
		bb.setUR(p5);
		System.out.println(bb.toString());
		System.out.println("The bounding box two dimensional: " + bb.is2D() + "\n");
		
		// Create the Buildings
		Zoo zoo1 = new Zoo(p6);
		Zoo zoo2 = new Zoo(p7);
		Aquarium aqr1 = new Aquarium(p8);
		Aquarium aqr2 = new Aquarium(p9);
		Asylum asy1 = new Asylum(p10);
		Asylum asy2 = new Asylum(p11);
		
		// Test some Building methods
		zoo1.setName("Zoo 1");
		zoo2.setName("Zoo 2");
		aqr1.setName("Aquarium 1");
		aqr2.setName("Aquarium 2");
		asy1.setName("Asylum 1");
		asy2.setName("Asylum 2");
		System.out.println("Here are the buildings:");
		System.out.println(zoo1.toString());
		System.out.println(zoo2.toString());
		System.out.println(aqr1.toString());
		System.out.println(aqr2.toString());
		System.out.println(asy1.toString());
		System.out.println(asy2.toString() + "\n");
		
		// Create the Disasters
		Flood noah = new Flood(p1, p2);
		Fire thomas = new Fire(p3, p14);
		Halftime adamLevine = new Halftime(p13, p12);
		
		//Test some Disaster methods
		System.out.println("Here are the zones of destruction:");
		System.out.println("Noah's Flood:            " + noah.toString());
		System.out.println("The Thomas Fire:         " + thomas.toString());
		System.out.println("Superbowl Halftime Show: " + adamLevine.toString());
		
		// Test if the buildings are within the disaster areas
		ArrayList<Building> bArray = new ArrayList<Building>();
		bArray.add(zoo1);
		bArray.add(zoo2);
		bArray.add(aqr1);
		bArray.add(aqr2);
		bArray.add(asy1);
		bArray.add(asy2);
		System.out.println("\n-----------------------------------------------------------------");
		
		int floodCount = 0, fireCount = 0, bowlCount = 0, none = 0, per = 0;
		
		for (int i=0; i<bArray.size(); i++) {
			
			per = floodCount + fireCount + bowlCount;
			
			if (noah.isInside(bArray.get(i))) {
				floodCount += 1;
				System.out.println("Folks in " + bArray.get(i).getName() + " " + noah.destroyed());
			}
			if (thomas.isInside(bArray.get(i))) {
				fireCount += 1;
				System.out.println("Folks in " + bArray.get(i).getName() + " " + thomas.destroyed());
			}
			if (adamLevine.isInside(bArray.get(i))) {
				bowlCount += 1;
				System.out.println("Folks in " + bArray.get(i).getName() + " " + adamLevine.destroyed());
			}
			if (per == floodCount + fireCount + bowlCount) {
				System.out.println(bArray.get(i).getName() + " was unscathed!");
				none += 1;
			}
			System.out.println();
		
		}
		
		int missed = bArray.size()*3 - floodCount - fireCount - bowlCount;
		
		System.out.println("In total, the flood hit " + floodCount + " building(s), the fire hit " + fireCount +
				" building(s), and the Superbowl Halftime show was audible to " + bowlCount + " building(s).");
		System.out.println(none + " building(s) were totally unaffected.");
		System.out.println("Disasters missed a building " + missed + " times.");
		
	}

}
