package HW4_pkg;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Polyline {
	
	//Member Variables
	
	private ArrayList<Point> points;
		
	//Constructors
		
	public Polyline() {
		setPoints(new ArrayList<Point>());
	}
		
	public Polyline(ArrayList<Point> points) {
		this.setPoints(points);
	}
	
	// Getters and Setters
	
	public void setPoints(ArrayList<Point> points) {
		this.points = points;
	}
		
	// Methods
	
	public boolean addPoint(Point p) {
		System.out.println("Point added");
		return points.add(p);
	}
	
	public String toString() {
		return "POLYLINE   " + Arrays.toString(getPoints().toArray());
	}
	
	public ArrayList<Point> getPoints(){
		return points;
	}
	
	public int size() {
		return points.size();
	}
	
	public boolean checkValid() {
		return points.size() >= 2;
	}
	
	public double getLength() {
		Iterator<Point> pointIterator = points.iterator();
		Point lastP = pointIterator.next();
		double distance = 0.0;
		while (pointIterator.hasNext()) {
			Point p = pointIterator.next();
			distance += lastP.distance(p);
			lastP = p;
		}
		return distance;
	}

}
