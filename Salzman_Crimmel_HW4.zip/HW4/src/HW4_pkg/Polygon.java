package HW4_pkg;
import java.util.ArrayList;
import java.util.Arrays;

public class Polygon extends Polyline {

	// Constructors

	public Polygon() {
		setPoints(new ArrayList<Point>());
	}
	public Polygon(ArrayList<Point> points) {
		super(points);
	}
	
	// Methods
	
	public String toString() {
		return "POLYGON   " + Arrays.toString(getPoints().toArray());
	}
	
	public boolean firstIsLast() {
		Point first = getPoints().get(0);
		Point last = getPoints().get(getPoints().size() - 1);
		if (first.getX() == last.getX() && first.getY() == last.getY()) {
			return true;
		}
		return false;
	}
	
	public boolean isValid() {
		
		if (Polygon.super.size() < 3) {
			return false;
		}
		
		if (firstIsLast()) { 
			return true;
		}
		return false;
	}
	
	public void makeValid() {
		if (Polygon.super.size() > 2) {
			if (!firstIsLast()) {
				Polygon.super.addPoint(getPoints().get(0));
			} else
				System.out.println("Polygon is already valid ya friggen goofball");
		} else {
			System.out.println("Polygon has too few points to be made valid");
		}
	}

}
