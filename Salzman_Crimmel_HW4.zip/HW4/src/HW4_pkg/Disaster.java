package HW4_pkg;

public class Disaster extends BoundingBox {
	//Attributes
	
	private int duration;
	
	//Constructors
	
	public Disaster(double x1, double y1, double x2, double y2) {
		super(x1, y1, x2, y2);
		this.setDuration(0);
	}
	
	public Disaster(Point LL, Point UR) {
		super(LL, UR);
		this.setDuration(0);
	}
	
	//Getters and Setters
	
	public int getDuration() {
		return duration;
	}
	
	public void setDuration(int d) {
		this.duration = d;
	}
	
	public String getType() {
		return "Disaster";
	}

}
