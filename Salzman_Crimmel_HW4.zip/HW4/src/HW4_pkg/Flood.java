package HW4_pkg;

public class Flood extends Disaster{
	
	public Flood(double x1, double y1, double x2, double y2) {
		super(x1, x2, y1, y2);
		this.setDuration(69);
	}
	
	public Flood(Point LL, Point UR) {
		super(LL, UR);
		this.setDuration(69);
	}
	
	public String getType() {
		return "Flood";
	}
	
	public String destroyed() {
		return "swam away";
	}

}
