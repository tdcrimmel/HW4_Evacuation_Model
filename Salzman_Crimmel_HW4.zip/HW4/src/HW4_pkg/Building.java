package HW4_pkg;
public class Building extends Point {
	
	public String name;
	
	// Constructors
	
	public Building(double x, double y) {
		super(x, y);
		this.x = x;
		this.y = y;
	}
	public Building(Point p) {
		super(p.getX(), p.getY());
		this.x = p.getX();
		this.y = p.getY();
	}
	
	// Getters and Setters
	public String getName() {
		return this.name;
	}
	
	// Methods
	
	public String toString() {
		return "BUILDING   (" + x + ", " + y + ")";
	}
	
}
