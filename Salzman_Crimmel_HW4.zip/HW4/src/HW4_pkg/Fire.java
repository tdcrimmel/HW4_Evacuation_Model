package HW4_pkg;

public class Fire extends Disaster {

	//Constructors
	public Fire(double x1, double y1, double x2, double y2) {
		super(x1, y1, x2, y2);
		// TODO Auto-generated constructor stub
	}
	
	public Fire(Point UL, Point LR) {
		super(LR, UL);
		this.setDuration(3);
	
	}
	
	//Getters
	
	public String getType() {
		return "Fire";
	}
	
	public String destroyed() {
		return "got a little crispy";
	}

}
