package HW4_pkg;
public class Point {
	
	// Member Variables
	
	protected double x, y;
	
	// Constructors
	
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	// Getters and Setters
	
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}	
	public void setX(double x) {
		this.x = x;
	}
	public void setY(double y) {
		this.y = y;
	}	
	
	// Methods
	
	public String toString() {
		return "(" + x + ", " + y + ")";
	}
	
	public double distance(Point p) {
		return Math.sqrt(Math.pow(this.x-p.x, 2) + Math.pow(this.y-p.y, 2));
	}

}
