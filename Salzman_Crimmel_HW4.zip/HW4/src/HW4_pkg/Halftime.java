package HW4_pkg;

public class Halftime extends Disaster{
	
	public Halftime(double x1, double y1, double x2, double y2) {
		super(x1, x2, y1, y2);
		this.setDuration(100000);
	}
	
	public Halftime(Point LL, Point UR) {
		super(LL, UR);
		this.setDuration(100000);
	}
	
	public String getType() {
		return "Halftime";
	}
	
	public String destroyed() {
		return "had to watch the Patriots win";
	}

}
