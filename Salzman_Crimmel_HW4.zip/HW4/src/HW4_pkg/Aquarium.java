package HW4_pkg;
public class Aquarium extends Building {

	public String name;
	
	// Constructors
	
	public Aquarium(double x, double y) {
		super(x, y);
		this.x = x;
		this.y = y;
	}
	public Aquarium(Point p) {
		super(p.getX(), p.getY());
		this.x = p.getX();
		this.y = p.getY();
	}
	
	// Getters and Setters
	
	public String getName() {
		return this.name;
	}
	public String setName(String s) {
		this.name = s;
		return name;
	}
	
	// Methods
	
	public String toString() {
		return name + "   (" + x + ", " + y + ")";
	}
	
}
